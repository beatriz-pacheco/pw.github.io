#include <iostream>
using namespace std;


int get_age (int age){
    cout << "Nome: ";
    cin >> age >> endl;
}

char get_name (char name){

};
class Person{
public:
    Person(Name&, Address&, Birthdate&);
    int age();
    String sex();
    Name name();

};
int main() {
    int age;
    char name;

    int get_age(age);







    cin >> "Nome:" >> name >> endl;
    cin >> "Email:" >> email >>endl;
    std::cout << "Hello, World!" << std::endl;
    return 0;
}
